/**
 * \file      defaite.h
 * \brief     Le header comportant les includes et prototype des fonctions
 *
 */


int ft_detect_defaite(char **grid);
