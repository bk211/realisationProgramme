/**
 * \file      afficha.h
 * \brief     Le header comportant les includes et prototype des fonctions
 *
 */

#include "color.h"
#define Dim 20
#include <stdio.h>
void afficher(char** grille);
