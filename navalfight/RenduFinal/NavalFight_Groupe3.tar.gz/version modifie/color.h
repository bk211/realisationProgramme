#include <stdio.h>
#include <stdio.h>
void red (); 
void green(); 

void yellow(); 

void blue(); 

void magenta(); 

void cyan(); 


void resetColor (); 

