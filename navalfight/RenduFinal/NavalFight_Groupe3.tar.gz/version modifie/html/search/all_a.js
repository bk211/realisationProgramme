var searchData=
[
  ['red',['red',['../color_8c.html#a39abd40f68d03c40857be1e74407efb9',1,'red():&#160;color.c'],['../color_8h.html#a39abd40f68d03c40857be1e74407efb9',1,'red():&#160;color.c']]],
  ['resetcolor',['resetColor',['../color_8c.html#afe00396766eb6b8ca4674de4c5d3d949',1,'resetColor():&#160;color.c'],['../color_8h.html#afe00396766eb6b8ca4674de4c5d3d949',1,'resetColor():&#160;color.c']]]
];
