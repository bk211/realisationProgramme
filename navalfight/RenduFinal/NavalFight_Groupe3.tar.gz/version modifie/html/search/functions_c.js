var searchData=
[
  ['yellow',['yellow',['../color_8c.html#ab0c10e6284be130a7973fa029a690ef7',1,'yellow():&#160;color.c'],['../color_8h.html#ab0c10e6284be130a7973fa029a690ef7',1,'yellow():&#160;color.c']]]
];
