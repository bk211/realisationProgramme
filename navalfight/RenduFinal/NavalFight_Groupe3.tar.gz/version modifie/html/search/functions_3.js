var searchData=
[
  ['def_5fodds',['def_odds',['../create__grid_8c.html#ad6b174d02a0b3bdbd16c426e0db703df',1,'def_odds(char **grid, int nbr_col, int nbr_line, int nbr_odds):&#160;create_grid.c'],['../create__grid_8h.html#ad6b174d02a0b3bdbd16c426e0db703df',1,'def_odds(char **grid, int nbr_col, int nbr_line, int nbr_odds):&#160;create_grid.c'],['../navalfight_8h.html#ad6b174d02a0b3bdbd16c426e0db703df',1,'def_odds(char **grid, int nbr_col, int nbr_line, int nbr_odds):&#160;create_grid.c']]]
];
