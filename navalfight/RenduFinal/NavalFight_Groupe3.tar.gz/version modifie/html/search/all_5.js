var searchData=
[
  ['green',['green',['../color_8c.html#a0df115437fbb77c0311e65300c65289e',1,'green():&#160;color.c'],['../color_8h.html#a0df115437fbb77c0311e65300c65289e',1,'green():&#160;color.c']]]
];
