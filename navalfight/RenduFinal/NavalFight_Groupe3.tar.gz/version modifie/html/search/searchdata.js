var indexSectionsWithContent =
{
  0: "abcdfgimnprtvy",
  1: "abcdmnpt",
  2: "abcdfgimnprvy",
  3: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros"
};

