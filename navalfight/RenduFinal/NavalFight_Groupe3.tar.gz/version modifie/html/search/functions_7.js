var searchData=
[
  ['magenta',['magenta',['../color_8c.html#ac481cf6f4061cd0d5e191c724d25e030',1,'magenta():&#160;color.c'],['../color_8h.html#ac481cf6f4061cd0d5e191c724d25e030',1,'magenta():&#160;color.c']]],
  ['main',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;main.c'],['../main_8h.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main.c'],['../navalfight_8h.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main.c']]]
];
