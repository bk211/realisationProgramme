var searchData=
[
  ['afficha_2ec',['afficha.c',['../afficha_8c.html',1,'']]],
  ['afficha_2eh',['afficha.h',['../afficha_8h.html',1,'']]]
];
