/**
 * \file      main.h
 * \brief     Le header comportant les includes et prototype des fonctions
 *
 */

#define Dim 20
#include "create_grid.h"
#include "boucle.h"


int main(void);
