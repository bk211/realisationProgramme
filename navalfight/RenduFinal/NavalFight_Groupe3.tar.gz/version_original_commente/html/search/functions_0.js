var searchData=
[
  ['afficher',['afficher',['../afficha_8c.html#a1eeb5989ccea2f6e0c5f7d47a1ad1f72',1,'afficher(char **grille):&#160;afficha.c'],['../navalfight_8h.html#a1eeb5989ccea2f6e0c5f7d47a1ad1f72',1,'afficher(char **grille):&#160;afficha.c']]],
  ['attaquer',['attaquer',['../boucle_8c.html#a671b4c4829e8d9d19dfcd73780499c56',1,'attaquer(char **grid):&#160;boucle.c'],['../navalfight_8h.html#a671b4c4829e8d9d19dfcd73780499c56',1,'attaquer(char **grid):&#160;boucle.c']]]
];
