#include <stdio.h>
void displayScore(int* tab_score,int *tab);
void compareScore(int a, int b);

